#ifndef _HANGMAN_H
#define _HANGMAN_H

/*
    hangman.h
        
    Class definition for the hangman class.

    assignment: CSCI 262 Project - Evil Hangman        

    author: 

    last modified: 9/24/2017
*/

#include <string>
#include <set>
#include <vector>
#include <map>

using namespace std;

/******************************************************************************
   class hangman

   Maintains game state for a game of hangman.

******************************************************************************/

class hangman {
public:
    hangman();

    // start a new game where player gets num_guesses unsuccessful tries
	void start_new_game(int num_guesses);

    // player guesses letter c; return whether or not char is in word
    bool process_guess(char c);

    // display current state of word - guessed characters or '-'
    string get_display_word();

    // How many guesses remain?
	int get_guesses_remaining();

    // What characters have already been guessed (for display)?
    string get_guessed_chars();

    // Has this character already been guessed?
    bool was_char_guessed(char c);

    // Has the game been won/lost?  (Else, it continues.)
    bool is_won();
    bool is_lost();

    // Return the true hidden word.
    string get_hidden_word();

    set<int> get_word_lengths();
    bool find_word_length(int len);
    void set_word_list(int le);
    //void set_guesses_remaining(int g);
    void set_word_length(int l);
    void set_current_guess(char c);
    void set_words_remaining(bool b);
    int get_correct_letters();
    int get_word_length();
private:
    set<string> words;
    set<int> word_lengths;
    set<string> word_list;
    string guessed_chars;
    int guesses_remaining;
    set<string> word_families;
    map<string, set<string>> word_families_map;
    int word_length;
    string current_word_family;
    string display_word;
    char current_guess;
    int correct_letters;
    bool words_remaining;
};

#endif
