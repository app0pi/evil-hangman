1. I did the entire project by myself.
2. I had many challenges such as making sure the characters displayed properly.  
	I fixed this problem by rechecking all my code until I found the bug.
3. I disliked how there were things on the starter code that needed to be adjusted
	even though there was no indication that they needed to be adjusted.
4. I spent 3 days on the project.
5. The novel feature I added was that the characters guessed were sorted in alphabetical order.

NOTE:  Extension given by CPW due to the ICPC competition.